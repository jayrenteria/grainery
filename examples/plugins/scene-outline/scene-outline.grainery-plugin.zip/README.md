# Scene Outline (Example Plugin)

This plugin adds a `Scenes` button to the plugin toolbar and opens a side panel with one entry per `sceneHeading` block.

Click any scene in the panel to jump directly to that scene in the editor.

## Permissions

- Optional: `ui:mount`

## Packaging

Package this folder as a `.grainery-plugin.zip` with `grainery-plugin.manifest.json` at archive root.
