# Review Notes Plugin Example

Demonstrates the declarative review-note workflow:

- Reviewer name + note entry via host-rendered panel input blocks
- Notes persisted in document plugin data (`document:set-plugin-data`)
- Inline highlights via `registerInlineAnnotationProvider`
- Jump/delete note actions from panel

Install by zipping with the manifest at archive root.
