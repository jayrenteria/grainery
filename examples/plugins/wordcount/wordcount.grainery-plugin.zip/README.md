# Word Count Utilities (Example Plugin)

This plugin demonstrates the Grainery plugin SDK surface:

- `registerElementLoopProvider`
- `registerCommand`
- `registerDocumentTransform`
- `registerExporter`

Package this directory as a `.grainery-plugin.zip` with `grainery-plugin.manifest.json` at the root to install via Settings -> Plugins -> Install from file.
